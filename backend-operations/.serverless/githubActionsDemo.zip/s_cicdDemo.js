
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cmjatin',
  applicationName: 'ci-cddemo',
  appUid: 'LpCrMkjGm9zS77cYR1',
  orgUid: 'd200ce66-af36-4a16-bdf0-6be1245150cf',
  deploymentUid: 'a95207fb-b733-47ae-827b-32faf0dc9a46',
  serviceName: 'githubActionsDemo',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'githubActionsDemo-dev-cicdDemo', timeout: 6 };

try {
  const userHandler = require('./serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}